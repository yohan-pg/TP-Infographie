//
//  transform.hpp
//  TP2
//
//  Created by Yohan Poirier-Ginter on 2018-04-15.
//
//

#ifndef transform_hpp
#define transform_hpp

#include <stdio.h>
#include "ofMain.h"

typedef ofMatrix4x4 Transform;

#endif /* transform_hpp */
