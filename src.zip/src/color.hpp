//
//  color.hpp
//  TP2
//
//  Created by Yohan Poirier-Ginter on 2018-04-15.
//
//

#ifndef color_hpp
#define color_hpp

#include <stdio.h>
#include "ofMain.h"

typedef ofFloatColor Color;

#endif /* color_hpp */
